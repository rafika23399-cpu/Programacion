#include <stdio.h>

int main()
{
 /* //1.Escribir un programa que pida dos números, los multiplique, los sume, los reste y los divida, cada resultado de la operación deberá salir por la consola: 
	
	int num1, num2, sum, difference, product, quotient;
	
	printf("Escribe 2 numeros:\n");
	scanf_s("%d %d", &num1, &num2);
	sum = num1 + num2;
	difference = num1 - num2;
	product = num1 * num2;
	quotient = num1 / num2;
	printf("El resultado de la suma es: %d\n", sum);
	printf("El resultado de la resta es: %d\n", difference);
	printf("El resultado de la division es: %d\n", quotient);
	printf("El resultado de la multiplicacion es: %d\n", product); */

/*	/2.Escribir un programa que pida el año actual y el año de nacimiento de una persona y le diga cuántos años tiene:

	int edad, bornYear, actualYear = 2025;
	
	printf("Introduce tu anio de nacimiento:\n");
	scanf_s("%d", &bornYear);
	edad = actualYear - bornYear;
	printf("Tu edad es: %d\n", edad);*/

/*	//3. Escribir un programa que pida una cantidad y obtenga el 21% de esa cantidad

	float value1, result;
	printf("Introduce una cantidad:\n");
	scanf_s("%f", &value1);
	result = value1 * 0.21;
	printf("El 21 porciento es: %0.1f\n", result);*/

/*	//4. Escribir un programa que pida un número de pulgadas y las convierta a centímetros. Nota: Una pulgada equivale a 2,54 centímetros.
	float inches, result;
	printf("Introduce el numero de pulgadas de tu pantalla:\n");
	scanf_s("%f", &inches);
	result = inches * 2.54;
	printf("Tu pantalla mide: %0.1f cm", result);*/

/*	//5. Escribir un programa que pida un número y calcule su cuadrado, sin utilizar funciones matemáticas
	float value1, square;
	printf("Introduce un numero: ");
	scanf_s("%f", &value1);
	square = value1 * value1;
	printf("El cuadrado es: %0.2f", square);*/

/*	//6. Escribir un programa que pida la base y altura de un triangulo y calcule el valor del área.Nota: area = (base * altura) / 2
	float base, height, area;

	printf("Introduce el valor de la base: ");
	scanf_s("%f", &base);
	printf("Introduce el valor de la altura: ");
	scanf_s("%f", &height);
	area = (base * height) / 2;
	printf("El area del triangulo es:%0.1f", area);*/
/*	//7. Escribir un programa que de el valor del área de un círculo a partir del radio introducido por el usuario.Nota: area = pi * radio al cuadrado
	
	float radius, area;
	printf("Introduce el radio del circulo: ");
	scanf_s("%f", &radius);
	area = radius * 3.14;
	printf("El area del circulo es: %0.1f", area);*/
}

